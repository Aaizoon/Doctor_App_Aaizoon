class Profile1 {
  final String name;
  final String email;
  final String mobilenumber;
  final String licensenumber;
  final String qualification;
  final String experience;
  final String address;
  final String date;
  final String fees;
  final String onlineFees;

  Profile1(this.name, this.email, this.mobilenumber, this.licensenumber, this.qualification, this.experience, this.address, this.date, this.fees, this.onlineFees);
}
