import 'package:aazioondoctorapp/profile/Data/availability.dart';

class Profile2 {
  final String clinicname;
  final String clinicaddress;
  final List<AvailabilityR> availiblity;

  Profile2(
    this.clinicname,
    this.clinicaddress,
    this.availiblity,
  );
}
