const imageBaseUrl = "https://aaizoon.in/api/download?path=";
// const imageBaseUrl= "http://aaizoon.com/api/public";
var appID = '74a81cc96de94f30a3058f601f122f17';
String doctorFirebaseId = "";
String patientFirebaseId = "";
String pName = "";
String peerAvatar = "";
