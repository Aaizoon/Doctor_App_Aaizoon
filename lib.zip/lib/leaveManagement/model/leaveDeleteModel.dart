class LeaveDeleteModel {
  String message;
  int status;

  LeaveDeleteModel({this.message, this.status});

  LeaveDeleteModel.fromJson(Map<String, dynamic> json) {
    message = json['message'];
    status = json['status'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['message'] = this.message;
    data['status'] = this.status;
    return data;
  }
}
